# 💡 Insight

Tuliskan pemikiran, ide, atau catatan mendalam tentang materi minggu ini.

## ✍️ Catatan
- Topik:
- Sumber:
- Refleksi:
