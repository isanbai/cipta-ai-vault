# 📅 Week 02
## 🎯 Fokus
(Tulis topik utama minggu ini)

## 📚 Materi
- [ ] Link atau ringkasan materi

## ✅ Checklist
- [ ] Tugas mingguan

## 💡 Insight
(Catat pemahaman & refleksi)

## 🔗 Terkait
[[Final_Roadmap_AI]]

#Roadmap #AI


---
## 📝 Catatan Asli
# 📅 Week 02
## 🎯 Fokus
Neural Network Dasar
## 📦 Materi
Klasifikasi MNIST + Backpropagation
## 💡 Insight
- Catat pemahaman baru atau hal penting dari materi minggu ini.
## 🔧 Proyek
#AmmarAI  #HireJob
Course Progress::
## 📚 Course Progress

- [ ] [Supervised Machine Learning](https://www.coursera.org/learn/machine-learning)
- [ ] [Python for Data Science](https://www.freecodecamp.org/learn/scientific-computing-with-python/)

- [ ] [Supervised Machine Learning](https://www.coursera.org/learn/machine-learning)
- [ ] [Python for Data Science](https://www.freecodecamp.org/learn/scientific-computing-with-python/)
- [ ] (tambahkan kursus jika ada)
## ✅ Checklist
- [ ] Review materi minggu ini
- [ ] Implementasi praktikal
- [ ] Update progres di GitHub & Notion