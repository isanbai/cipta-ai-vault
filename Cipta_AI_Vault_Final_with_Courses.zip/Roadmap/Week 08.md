# 📅 Week 08
## 🎯 Fokus
(Tulis topik utama minggu ini)

## 📚 Materi
- [ ] Link atau ringkasan materi

## ✅ Checklist
- [ ] Tugas mingguan

## 💡 Insight
(Catat pemahaman & refleksi)

## 🔗 Terkait
[[Final_Roadmap_AI]]

#Roadmap #AI


---
## 📝 Catatan Asli
# 📅 Week 08
## 🎯 Fokus
Vector Store & Reranker
## 📦 Materi
Qdrant + Cohere Reranker
## 💡 Insight
- Catat pemahaman baru atau hal penting dari materi minggu ini.
## 🔧 Proyek
#AmmarAI  #HireJob
Course Progress::
## 📚 Course Progress

- [ ] [RAG with OpenAI](https://platform.openai.com/docs/guides/retrieval)
- [ ] [Intro to Qdrant + LlamaIndex](https://qdrant.tech/documentation/)

- [ ] [RAG with OpenAI](https://platform.openai.com/docs/guides/retrieval)
- [ ] [Intro to Qdrant + LlamaIndex](https://qdrant.tech/documentation/)
- [ ] (tambahkan kursus jika ada)
## ✅ Checklist
- [ ] Review materi minggu ini
- [ ] Implementasi praktikal
- [ ] Update progres di GitHub & Notion