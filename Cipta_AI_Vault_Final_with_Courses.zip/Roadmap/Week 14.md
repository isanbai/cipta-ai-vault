# 📅 Week 14
## 🎯 Fokus
(Tulis topik utama minggu ini)

## 📚 Materi
- [ ] Link atau ringkasan materi

## ✅ Checklist
- [ ] Tugas mingguan

## 💡 Insight
(Catat pemahaman & refleksi)

## 🔗 Terkait
[[Final_Roadmap_AI]]

#Roadmap #AI


---
## 📝 Catatan Asli
# 📅 Week 14
## 🎯 Fokus:
Ekspresi Wajah & Scoring
## 📚 Materi:
Ekspresi pelamar + dashboard HR
## 💡 Insight:
## 📌 Proyek:
#HireJob
## ✅ Checklist: