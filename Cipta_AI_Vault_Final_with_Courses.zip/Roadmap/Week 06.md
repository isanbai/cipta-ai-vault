# 📅 Week 06
## 🎯 Fokus
(Tulis topik utama minggu ini)

## 📚 Materi
- [ ] Link atau ringkasan materi

## ✅ Checklist
- [ ] Tugas mingguan

## 💡 Insight
(Catat pemahaman & refleksi)

## 🔗 Terkait
[[Final_Roadmap_AI]]

#Roadmap #AI


---
## 📝 Catatan Asli
# 📅 Week 06
## 🎯 Fokus
LangChain & Embedding
## 📦 Materi
Build RAG untuk jawaban AI
## 💡 Insight
- Catat pemahaman baru atau hal penting dari materi minggu ini.
## 🔧 Proyek
#AmmarAI  #HireJob
Course Progress::
## 📚 Course Progress

- [ ] [Text Classification with Transformers](https://huggingface.co/course/chapter3)
- [ ] [TTS dengan Coqui](https://learn.coqui.ai/)

- [ ] [Text Classification with Transformers](https://huggingface.co/course/chapter3)
- [ ] [TTS dengan Coqui](https://learn.coqui.ai/)
- [ ] (tambahkan kursus jika ada)
## ✅ Checklist
- [ ] Review materi minggu ini
- [ ] Implementasi praktikal
- [ ] Update progres di GitHub & Notion