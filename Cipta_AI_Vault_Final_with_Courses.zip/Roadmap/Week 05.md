# 📅 Week 05
## 🎯 Fokus
(Tulis topik utama minggu ini)

## 📚 Materi
- [ ] Link atau ringkasan materi

## ✅ Checklist
- [ ] Tugas mingguan

## 💡 Insight
(Catat pemahaman & refleksi)

## 🔗 Terkait
[[Final_Roadmap_AI]]

#Roadmap #AI


---
## 📝 Catatan Asli
# 📅 Week 05
## 🎯 Fokus
NLP Dasar & Dataset
## 📦 Materi
Preprocessing CV + Job Desc
## 💡 Insight
- Catat pemahaman baru atau hal penting dari materi minggu ini.
## 🔧 Proyek
#AmmarAI  #HireJob
Course Progress::
## 📚 Course Progress

- [ ] [Transfer Learning for Images](https://www.kaggle.com/learn/computer-vision)
- [ ] [Hugging Face: Transformers Course](https://huggingface.co/course/chapter1)

- [ ] [Transfer Learning for Images](https://www.kaggle.com/learn/computer-vision)
- [ ] [Hugging Face: Transformers Course](https://huggingface.co/course/chapter1)
- [ ] (tambahkan kursus jika ada)
## ✅ Checklist
- [ ] Review materi minggu ini
- [ ] Implementasi praktikal
- [ ] Update progres di GitHub & Notion