# 📅 Week 07
## 🎯 Fokus
(Tulis topik utama minggu ini)

## 📚 Materi
- [ ] Link atau ringkasan materi

## ✅ Checklist
- [ ] Tugas mingguan

## 💡 Insight
(Catat pemahaman & refleksi)

## 🔗 Terkait
[[Final_Roadmap_AI]]

#Roadmap #AI


---
## 📝 Catatan Asli
# 📅 Week 07
## 🎯 Fokus
Tuning Model LLM
## 📦 Materi
LoRA / QLoRA pada model lokal
## 💡 Insight
- Catat pemahaman baru atau hal penting dari materi minggu ini.
## 🔧 Proyek
#AmmarAI  #HireJob
Course Progress::
## 📚 Course Progress

- [ ] [LangChain for Beginners](https://learn.deeplearning.ai/langchain)
- [ ] [HuggingFace Embedding Models](https://huggingface.co/spaces/mteb/leaderboard)

- [ ] [LangChain for Beginners](https://learn.deeplearning.ai/langchain)
- [ ] [HuggingFace Embedding Models](https://huggingface.co/spaces/mteb/leaderboard)
- [ ] (tambahkan kursus jika ada)
## ✅ Checklist
- [ ] Review materi minggu ini
- [ ] Implementasi praktikal
- [ ] Update progres di GitHub & Notion