# 📅 Week 11
## 🎯 Fokus
(Tulis topik utama minggu ini)

## 📚 Materi
- [ ] Link atau ringkasan materi

## ✅ Checklist
- [ ] Tugas mingguan

## 💡 Insight
(Catat pemahaman & refleksi)

## 🔗 Terkait
[[Final_Roadmap_AI]]

#Roadmap #AI


---
## 📝 Catatan Asli
# 📅 Week 11
## 🎯 Fokus
Docker + Deployment
## 📦 Materi
Containerisasi proyek AI
## 💡 Insight
- Catat pemahaman baru atau hal penting dari materi minggu ini.
## 🔧 Proyek
#AmmarAI  #HireJob
Course Progress::
## 📚 Course Progress

- [ ] [Build AI Web App with React](https://www.youtube.com/watch?v=9Boz2RH1IF0)
- [ ] [Cloud Deployment with Railway](https://railway.app/)

- [ ] [Build AI Web App with React](https://www.youtube.com/watch?v=9Boz2RH1IF0)
- [ ] [Cloud Deployment with Railway](https://railway.app/)
- [ ] (tambahkan kursus jika ada)
## ✅ Checklist
- [ ] Review materi minggu ini
- [ ] Implementasi praktikal
- [ ] Update progres di GitHub & Notion