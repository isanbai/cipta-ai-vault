# 📅 Week 03
## 🎯 Fokus
(Tulis topik utama minggu ini)

## 📚 Materi
- [ ] Link atau ringkasan materi

## ✅ Checklist
- [ ] Tugas mingguan

## 💡 Insight
(Catat pemahaman & refleksi)

## 🔗 Terkait
[[Final_Roadmap_AI]]

#Roadmap #AI


---
## 📝 Catatan Asli
# 📅 Week 03
## 🎯 Fokus
CNN & Dataset
## 📦 Materi
Ekspresi wajah anak + transfer learning
## 💡 Insight
- Catat pemahaman baru atau hal penting dari materi minggu ini.
## 🔧 Proyek
#AmmarAI  #HireJob
Course Progress::
## 📚 Course Progress

- [ ] [Intro to Neural Networks with Keras](https://www.coursera.org/learn/neural-networks-deep-learning)

- [ ] [Intro to Neural Networks with Keras](https://www.coursera.org/learn/neural-networks-deep-learning)
- [ ] (tambahkan kursus jika ada)
## ✅ Checklist
- [ ] Review materi minggu ini
- [ ] Implementasi praktikal
- [ ] Update progres di GitHub & Notion