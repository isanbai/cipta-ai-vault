# 📅 Week 04
## 🎯 Fokus
(Tulis topik utama minggu ini)

## 📚 Materi
- [ ] Link atau ringkasan materi

## ✅ Checklist
- [ ] Tugas mingguan

## 💡 Insight
(Catat pemahaman & refleksi)

## 🔗 Terkait
[[Final_Roadmap_AI]]

#Roadmap #AI


---
## 📝 Catatan Asli
# 📅 Week 04
## 🎯 Fokus
LSTM & TTS
## 📦 Materi
Text-to-speech + prediksi sekuens
## 💡 Insight
- Catat pemahaman baru atau hal penting dari materi minggu ini.
## 🔧 Proyek
#AmmarAI  #HireJob
Course Progress::
## 📚 Course Progress

- [ ] [Convolutional Neural Networks](https://www.coursera.org/learn/convolutional-neural-networks)
- [ ] [Google Teachable Machine](https://teachablemachine.withgoogle.com/)

- [ ] [Convolutional Neural Networks](https://www.coursera.org/learn/convolutional-neural-networks)
- [ ] [Google Teachable Machine](https://teachablemachine.withgoogle.com/)
- [ ] (tambahkan kursus jika ada)
## ✅ Checklist
- [ ] Review materi minggu ini
- [ ] Implementasi praktikal
- [ ] Update progres di GitHub & Notion