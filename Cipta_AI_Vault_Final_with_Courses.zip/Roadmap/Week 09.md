# 📅 Week 09
## 🎯 Fokus
(Tulis topik utama minggu ini)

## 📚 Materi
- [ ] Link atau ringkasan materi

## ✅ Checklist
- [ ] Tugas mingguan

## 💡 Insight
(Catat pemahaman & refleksi)

## 🔗 Terkait
[[Final_Roadmap_AI]]

#Roadmap #AI


---
## 📝 Catatan Asli
# 📅 Week 09
## 🎯 Fokus
Audio & Video AI
## 📦 Materi
Voice Cloning + Ekstrak Wajah
## 💡 Insight
- Catat pemahaman baru atau hal penting dari materi minggu ini.
## 🔧 Proyek
#AmmarAI  #HireJob
Course Progress::
## 📚 Course Progress

- [ ] [Cohere Reranker Demo](https://cohere.com/re-rank)
- [ ] [RLHF Paper Summary](https://huggingface.co/blog/rlhf)

- [ ] [Cohere Reranker Demo](https://cohere.com/re-rank)
- [ ] [RLHF Paper Summary](https://huggingface.co/blog/rlhf)
- [ ] (tambahkan kursus jika ada)
## ✅ Checklist
- [ ] Review materi minggu ini
- [ ] Implementasi praktikal
- [ ] Update progres di GitHub & Notion