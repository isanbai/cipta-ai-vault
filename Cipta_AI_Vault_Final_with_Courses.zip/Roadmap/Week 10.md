# 📅 Week 10
## 🎯 Fokus
(Tulis topik utama minggu ini)

## 📚 Materi
- [ ] Link atau ringkasan materi

## ✅ Checklist
- [ ] Tugas mingguan

## 💡 Insight
(Catat pemahaman & refleksi)

## 🔗 Terkait
[[Final_Roadmap_AI]]

#Roadmap #AI


---
## 📝 Catatan Asli
# 📅 Week 10
## 🎯 Fokus
React + FastAPI
## 📦 Materi
Desain UI dan REST API AI
## 💡 Insight
- Catat pemahaman baru atau hal penting dari materi minggu ini.
## 🔧 Proyek
#AmmarAI  #HireJob
Course Progress::
## 📚 Course Progress

- [ ] [Docker for AI](https://www.youtube.com/watch?v=9zUHg7xjIqQ)
- [ ] [FastAPI Basics](https://www.youtube.com/watch?v=0sOvCWFmrtA)

- [ ] [Docker for AI](https://www.youtube.com/watch?v=9zUHg7xjIqQ)
- [ ] [FastAPI Basics](https://www.youtube.com/watch?v=0sOvCWFmrtA)
- [ ] (tambahkan kursus jika ada)
## ✅ Checklist
- [ ] Review materi minggu ini
- [ ] Implementasi praktikal
- [ ] Update progres di GitHub & Notion