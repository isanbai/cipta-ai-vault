# 📚 Obsidian Vault – AI Pembelajaran & Proyek

Gunakan struktur ini untuk mencatat proses belajar AI dan proyek nyata seperti Ammar-AI, HireJob, Dakwah-AI, dan BarangLagi.
