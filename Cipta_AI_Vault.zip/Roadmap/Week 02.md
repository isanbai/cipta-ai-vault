# 📅 Week 02

## 🎯 Fokus
Neural Network Dasar

## 📦 Materi
Klasifikasi MNIST + Backpropagation

## 💡 Insight
- Catat pemahaman baru atau hal penting dari materi minggu ini.

## 🔧 Proyek
#AmmarAI  #HireJob

## 📚 Course Progress
- [ ] (tambahkan kursus jika ada)

## ✅ Checklist
- [ ] Review materi minggu ini
- [ ] Implementasi praktikal
- [ ] Update progres di GitHub & Notion
