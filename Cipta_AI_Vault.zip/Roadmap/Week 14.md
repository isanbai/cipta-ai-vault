# 📅 Week 14
## 🎯 Fokus:
Ekspresi Wajah & Scoring
## 📚 Materi:
Ekspresi pelamar + dashboard HR
## 💡 Insight:
## 📌 Proyek:
#HireJob
## ✅ Checklist: