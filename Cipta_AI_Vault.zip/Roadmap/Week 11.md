# 📅 WEEK 11 – Frontend UI (React/Chainlit) `#All Projects`
#### 🎯 Goals:
- React dasar, Tailwind, fetch API
- Chainlit + komponen UI

#### 📚 Course Progress:
- [ ] [Build AI Web App (YouTube)](https://www.youtube.com/watch?v=9Boz2RH1IF0)
- [ ] [FullstackOpen – React](https://fullstackopen.com/en/)
- [ ] [React Docs Tutorial](https://react.dev/learn)

### 🛠️ Project Tasks:
- [ ] UI Apply Job ( #HireJob)
- [ ] UI live scoring pelamar ( #HireJob )
- [ ] UI Cari Produk ( #BarangLagi)