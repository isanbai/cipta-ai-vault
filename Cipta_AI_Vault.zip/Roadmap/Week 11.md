# 📅 Week 11

## 🎯 Fokus
Docker + Deployment

## 📦 Materi
Containerisasi proyek AI

## 💡 Insight
- Catat pemahaman baru atau hal penting dari materi minggu ini.

## 🔧 Proyek
#AmmarAI  #HireJob

## 📚 Course Progress
- [ ] (tambahkan kursus jika ada)

## ✅ Checklist
- [ ] Review materi minggu ini
- [ ] Implementasi praktikal
- [ ] Update progres di GitHub & Notion
