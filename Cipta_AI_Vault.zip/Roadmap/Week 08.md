# 📅 WEEK 8 – LLM Inference & Ollama `#HireJob #DakwahAI`
#### 🎯 Goals:
- Setup Ollama, LLaMA, Mistral
- OpenAI API vs Local Model
- Prompting & respons

#### 📚 Course Progress:
- [ ] [Intro HuggingFace NLP](https://huggingface.co/learn/nlp-course/chapter1)
- [ ] [RAG with OpenAI](https://platform.openai.com/docs/guides/retrieval)

#### 🛠️ Project Tasks:
- [ ] Bot Tanya CV ( #HireJob)
- [ ] Parsing CV pakai LLM ( #HireJob )
- [ ] Chat Islami ( #Dakwah-AI)