# 📅 Week 06

## 🎯 Fokus
LangChain & Embedding

## 📦 Materi
Build RAG untuk jawaban AI

## 💡 Insight
- Catat pemahaman baru atau hal penting dari materi minggu ini.

## 🔧 Proyek
#AmmarAI  #HireJob

## 📚 Course Progress
- [ ] (tambahkan kursus jika ada)

## ✅ Checklist
- [ ] Review materi minggu ini
- [ ] Implementasi praktikal
- [ ] Update progres di GitHub & Notion
