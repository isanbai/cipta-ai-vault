# 📅 WEEK 6 – TTS & Voice Cloning `#AmmarAI #DakwahAI`
#### 🎯 Goals:
- Text to Speech (TTS) pipeline
- Mel Spectrogram, suara sintetik
- Tools: Coqui, Bark, ElevenLabs

#### 📚 Course Progress:
- [ ] [Text Classification with Transformers](https://huggingface.co/course/chapter3)
- [ ] [TTS Coqui Learn](https://learn.coqui.ai/)

#### 🛠️ Project Tasks:
- [ ] Voice anak ( #AmmarAI)
- [ ] Voice ustadz ( #DakwahAI)