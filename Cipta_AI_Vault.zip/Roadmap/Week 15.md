## ✅ Checklist
- [ ] Tonton kursus CNN
- [ ] Baca artikel transfer learning
