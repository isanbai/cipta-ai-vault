# 📅 Week 01
## 🎯 Fokus
Dasar Python & AI Thinking
## 📦 Materi
Script parsing metadata + CV

## 💡 Insight

- [ ] Belajar parsing metadata
- [ ] Fungsi split() di Python

## 🔧 Proyek
#AmmarAI  #HireJob

## 📚 Course Progress
- [x] [AI for Everyone](https://www.coursera.org/learn/ai-for-everyone/home/welcome) ✅ 2025-06-22
- [x] [Generative AI for Everyone](https://www.coursera.org/learn/generative-ai-for-everyone/home/welcome) ✅ 2025-06-29
- [ ] [AI Python for Beginners](https://www.coursera.org/learn/ai-python-for-beginners/home/welcome)

## ✅ Checklist
- [ ] Review materi minggu ini
- [ ] Implementasi praktikal
- [ ] Update progres di GitHub & Notion

## 🔗 Terkait
[[Final_Roadmap_AI]]

#Roadmap #AI