# 📅 Week 01

## 🎯 Fokus
Dasar Python & AI Thinking

## 📦 Materi
Script parsing metadata + CV

## 💡 Insight
- Catat pemahaman baru atau hal penting dari materi minggu ini.

## 🔧 Proyek
#AmmarAI  #HireJob

## 📚 Course Progress
- [x] [AI for Everyone](https://www.coursera.org/learn/ai-for-everyone/home/welcome)
- [x] [Generative AI for Everyone](https://www.coursera.org/learn/generative-ai-for-everyone/home/welcome)
- [ ] [AI Python for Beginners](https://www.coursera.org/learn/ai-python-for-beginners/home/welcome)


## ✅ Checklist
- [ ] Review materi minggu ini
- [ ] Implementasi praktikal
- [ ] Update progres di GitHub & Notion
