# 📅 Week 13

## 🎯 Fokus: 
AI Interview & STT
## 📚 Materi: 
Transkrip jawaban pelamar
## 💡 Insight:

## 📌 Proyek: 
#HireJob
## ✅ Checklist:

