# 📅 WEEK 13 – AI Interview + Ekspresi Wajah `#HireJob`
#### 🎯 Goals:
- WebRTC + Whisper untuk rekaman
- Analisis ekspresi wajah (DeepFace/MediaPipe)
- LLM Scoring interview

#### 🛠️ Project Tasks:
- [ ] AI Interview + Webcam
- [ ] Dashboard HR Live Score