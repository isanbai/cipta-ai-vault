# 📚 Coursera Tracker

- [[AI for Everyone]] – ✅ Selesai
- [[Generative AI for Everyone]] – ✅ Selesai
- [[AI Python for Beginners]] – 🚧 Sedang dikerjakan
